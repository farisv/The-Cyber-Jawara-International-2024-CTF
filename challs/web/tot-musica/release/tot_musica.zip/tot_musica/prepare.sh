#!/bin/bash

cd php; composer install;

